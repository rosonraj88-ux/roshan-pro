# Roshan Anand — Portfolio Website

A modern, dark-themed personal portfolio with neon blue/teal/purple accents, 
smooth animations, typing effects, and a fully responsive layout.

---

## 🗂️ Folder Structure

```
portfolio/
├── index.html        ← Main HTML file (everything is self-contained)
└── README.md         ← This file
```

> All CSS and JavaScript are embedded in `index.html` for fast loading and simplicity.

---

## ✏️ Customization Checklist

Before deploying, update these placeholders inside `index.html`:

| Placeholder                        | What to change                          |
|------------------------------------|-----------------------------------------|
| `roshananand@example.com`          | Your real email address                 |
| `https://github.com/roshananand`   | Your actual GitHub profile URL          |
| `https://linkedin.com/in/roshananand` | Your LinkedIn URL (or remove it)     |
| Project `href="#"` on demo buttons | Replace with actual live demo URLs      |
| Profile image (initials `RA`)      | Replace the `.profile-img` div with an `<img>` tag |

### 🖼️ Adding a Real Profile Photo

Find this block in `index.html`:
```html
<div class="profile-img">RA</div>
```
Replace with:
```html
<img class="profile-img" src="photo.jpg" alt="Roshan Anand" style="object-fit:cover;" />
```
Then place your `photo.jpg` in the same folder.

---

## 🚀 Deploy to GitHub Pages (Free Hosting)

### Step 1 — Create a GitHub Repository
1. Go to [github.com](https://github.com) and log in
2. Click **New Repository**
3. Name it: `roshananand.github.io` (use your actual GitHub username)
4. Set it to **Public**
5. Click **Create repository**

### Step 2 — Upload Your Files
**Option A — Via browser (easiest):**
1. Open the repository on GitHub
2. Click **Add file → Upload files**
3. Drag and drop `index.html` and any other files
4. Click **Commit changes**

**Option B — Via Git (recommended):**
```bash
git init
git add .
git commit -m "Initial portfolio commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/roshananand.github.io.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages
1. Go to your repo → **Settings** → **Pages**
2. Under **Source**, select `main` branch, folder `/ (root)`
3. Click **Save**
4. Wait ~1 minute, then visit: `https://YOUR_USERNAME.github.io`

---

## 🛠️ Contact Form Setup (Optional)

The form currently shows a success message locally.  
To actually receive emails, use one of these free services:

### Formspree (Easiest)
1. Sign up at [formspree.io](https://formspree.io)
2. Create a new form — copy your Form ID (e.g. `xpzvrgwb`)
3. In `index.html`, find the `handleSubmit()` function and replace with:
```javascript
async function handleSubmit() {
  const data = {
    name: document.getElementById('formName').value,
    email: document.getElementById('formEmail').value,
    message: document.getElementById('formMsg').value
  };
  await fetch('https://formspree.io/f/YOUR_FORM_ID', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  document.getElementById('form-feedback').style.display = 'block';
}
```

---

## 💡 Tips

- Update project links as you build and deploy them
- Keep `index.html` under 500 KB for fastest load times
- Add a `favicon.ico` in the same folder for a browser tab icon
- Test on mobile before deploying using Chrome DevTools (F12 → Toggle device)

---

*Built with pure HTML, CSS & JavaScript — no frameworks required.*
